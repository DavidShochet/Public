using FreshMvvm;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace iOSSecondaryToolbarMenubar
{
	public partial class App : Application
	{
		public App ()
		{
			InitializeComponent();

			//MainPage = new NavigationPage(new MainPage())
			//{
			//	BarBackgroundColor = Color.FromHex("#E58A77"),
			//	BarTextColor = Color.White
			//};

			Page page = FreshPageModelResolver.ResolvePageModel<MainPageModel>();
			FreshNavigationContainer simpleNav = new FreshNavigationContainer(page);
			MainPage = simpleNav;
		}

		protected override void OnStart ()
		{
			// Handle when your app starts
		}

		protected override void OnSleep ()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume ()
		{
			// Handle when your app resumes
		}
	}
}

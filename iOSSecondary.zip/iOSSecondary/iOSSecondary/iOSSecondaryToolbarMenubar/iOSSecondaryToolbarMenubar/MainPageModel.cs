﻿using FreshMvvm;
using Xamarin.Forms;

namespace iOSSecondaryToolbarMenubar
{
    public class MainPageModel : FreshBasePageModel
    {
        public override void Init(object initData)
        {
            CurrentPage.ToolbarItems.Add(new ToolbarItem() { Text = "Item 1 PM", /*Command = AboutCommand, */Priority = 0, Order = ToolbarItemOrder.Secondary });
            CurrentPage.ToolbarItems.Add(new ToolbarItem() { Text = "Item 2 PM", /*Command = CallCommand, */Priority = 0, Order = ToolbarItemOrder.Secondary });
        }
    }
}

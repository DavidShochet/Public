# iOSSecondaryToolbarMenubar
This is a Xamarin forms based repository in which I created a menu bar in iPhone and iPad toolbar for secondary toolbar items same as android.

![alt text](https://us.v-cdn.net/5019960/uploads/editor/19/plyk7p50r0el.png)

Refernce to this repository: This repo is based on [this](https://forums.xamarin.com/discussion/112957/content-page-secondary-toolbar-items-in-ios-same-as-android#latest) xamarin forum discussion. 
